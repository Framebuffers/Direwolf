export { CreateManagerResource } from './manager.resource.js';
export { CreateOfficeResource } from './office.resource.js';
