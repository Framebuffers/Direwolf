export { CreateOwnerResource } from './owner.resource.js';
export { CreateCarResource } from './car.resource.js';
export { CreateSellerResource } from './seller.resource.js';
