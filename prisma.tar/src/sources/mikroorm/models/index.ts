export { Owner } from './owner.model.js';
export { Car } from './car.model.js';
export { Seller } from './seller.model.js';
