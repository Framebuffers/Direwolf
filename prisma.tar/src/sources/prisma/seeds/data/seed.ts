import { Faker, faker } from '@faker-js/faker';
import { Prisma, PrismaClient } from '@prisma/client';
import { now, uniqueId } from 'lodash';
import { wolfpack } from './index.js';

const prisma = new PrismaClient()
const fileName = faker.system.fileName();

const test = `
testResult: {
  CreatedAt: faker.date.recent(),
  GUID: crypto.randomUUID(),
  ModelHealthReaper: {
    dataCount: {
      viewsInsideDocument: faker.datatype.number(100),
      notInSheets: faker.datatype.number(100),
      annotativeElements: faker.datatype.number(100),
      externalRefs: faker.datatype.number(100),
      modelGroups: faker.datatype.number(100),
      detailGroups: faker.datatype.number(100),
      designOptions: faker.datatype.number(100),
      levels: faker.datatype.number(10),
      grids: faker.datatype.number(10),
      warns: faker.datatype.number(5000),
      unenclosedRoom: faker.datatype.number(100),
      viewports: faker.datatype.number(100),
      unconnectedDucts: faker.datatype.number(100),
      unconnectedPipes: faker.datatype.number(100),
      unconnectedElectrical: faker.datatype.number(100),
      nonNativeStyles: faker.datatype.number(100),
      isFlipped: faker.datatype.number(10000),
      worksetElementCount: faker.datatype.number(10000),
    },
  },
}
`

async function main() {
  for (let i = 1; 1 <= 50; i++) {
    const entry = await prisma.wolfpack.upsert({
      where: { id: i },
      update: {},
      create: {
        documentName: fileName,
        fileOrigin: `C:\\${fileName}.rvt`,
        documentVersion: crypto.randomUUID(),
        wasCompleted: faker.datatype.boolean(),
        timeTaken: parseFloat((Math.random() * (10.0 - 0.0001)).toFixed(4)),
        createdAt: new Date().getUTCDate.toString(),
        guid: crypto.randomUUID(),
        testName: `${faker.commerce.productMaterial()}_is${faker.commerce.productAdjective()}`,
        results: test,
        testId: faker.datatype.number({ min: 1, max: 1000 }),
      }
    });
    console.log(entry);
  }
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })
