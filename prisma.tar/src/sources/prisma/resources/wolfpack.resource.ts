import { menu } from '../../../admin/index.js';
import { useEnvironmentVariableToDisableActions } from '../../../admin/features/useEnvironmentVariableToDisableActions.js';
import { ResourceFunction } from '../../../admin/types/index.js';
import { client, dmmf } from '../config.js';
import { defaultDecoder } from 'qs';
import { wolfpack } from '../seeds/data/index.js';

export const CreateWolfpackResource: ResourceFunction<{
  model: typeof dmmf.modelMap.Wolfpack;
  client: typeof client;
}> = () => ({
  resource: {
    model: dmmf.modelMap.Wolfpack,
    client,
  },
  features: [useEnvironmentVariableToDisableActions()],
  options: {
    navigation: menu.prisma,
    properties: {
      content: { type: 'richtext' },
      someJson: { type: 'mixed', isArray: true },
      'someJson.number': { type: 'number' },
      'someJson.string': { type: 'string' },
      'someJson.boolean': { type: 'boolean' },
      'someJson.date': { type: 'datetime' },
    },
  },
});

export default wolfpack;