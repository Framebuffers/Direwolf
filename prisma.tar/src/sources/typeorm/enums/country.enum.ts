export enum CountryEnum {
  Poland = 'PL',
  GreatBritain = 'GB',
  Germany = 'DE',
}
