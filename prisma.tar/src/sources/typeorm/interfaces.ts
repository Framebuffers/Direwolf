export interface PostPayload {
  email: string;
}
