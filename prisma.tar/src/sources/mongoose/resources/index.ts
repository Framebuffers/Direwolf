export { CreateAdminResource } from './admin.resource.js';
export { CreateUserResource } from './user.resource.js';
export { CreateArticleResource } from './article.resource.js';
export { CreateCategoryResource } from './category.resource.js';
export { CreateCommentResource } from './comment.resource.js';
export { CreateComplicatedResource } from './complicated.resource.js';
