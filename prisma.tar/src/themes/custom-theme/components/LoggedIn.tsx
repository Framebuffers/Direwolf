import { Box } from '@adminjs/design-system';
import React from 'react';

const LoggedIn = () => <Box mr="lg" />;

export default LoggedIn;
